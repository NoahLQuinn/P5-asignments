//the spiral represents a hurricane, I plan to ask you about loading textures inclass to apply a similar to the smoke example for clouts coming off the spirals.
function countingFrames (){
  let f = frameCount;
  print (f);
}

function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);
  ellipseMode(CENTER);
}

function draw() {
  let x = 0;
  let y = 0;
  background(220);
  translate (mouseX, mouseY);
  frameRate(60);
  rotate(frameCount*5);
  scale(.25);
  weatherSpiral (x, y);
  rotate (45);
  weatherSpiral (x, y);
  rotate (180);
  weatherSpiral (x, y);
  rotate (90);
  weatherSpiral (x, y);

  countingFrames();
  
  
}

function weatherSpiral (x, y) {
  push();
  stroke (1);
  strokeWeight (1);
  point (x,y);
  
  for (let i = 0; i <= 3; i++) {
    
    for (let a = 0; a <= 360; a += 100) {
      
      let r = 50*i;
      noFill();
  bezier(x - cos(a) * r, y + cos(a) * r,
         x - cos(a) * r,
         y,
         x ,
         y,
         x , y);
    }
  }

  pop();
}