function setup() {
  createCanvas(400, 400);
}
function draw() {
  background(220);
  setCenter(width/2, height/2);
  noFill();
  polarLines(15, 200, 0);
  polarHexagon(30, 50, 0);
  
  polarEllipses(50, 0, 0, 0, function(...args) {
    stroke(args[2]*10);
    fill(args[0]*5, args[0]*4, args[0]*3, 30);
      args[3] = args[1]*6;
      args[1] = args[3]*6;
      return args;
    
  });
}