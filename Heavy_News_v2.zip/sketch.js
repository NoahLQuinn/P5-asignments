//Convinient that the lecture after the last asignment was on loading images
let map;
let hur;

function preload () {
 map = loadImage ('map.jpg');
 hur = loadImage ('hurricane.png');
}

function setup() {
  createCanvas(735, 413);
  angleMode(DEGREES);
  ellipseMode(CENTER);
}

function draw() {
  let f = frameCount;
  let x = 0;
  let y = 0;
  background(220);
  frameRate(60);


  image(map, 0, 0);
  textSize(25);
  text (f ,width/2 ,100, 100, 100 );
  fill(222, 100, 222);
  stroke (100);

  
  translate (mouseX, mouseY);
  rotate(frameCount*5);
  scale(.45);
  image(hur, x-211, y-183);
  weatherSpiral (x, y);
  rotate (45);
  weatherSpiral (x, y);
  rotate (180);
  weatherSpiral (x, y);
  rotate (90);
  weatherSpiral (x, y);

}

function weatherSpiral (x, y) {
  push();
  stroke (1);
  strokeWeight (1);
  point (x,y);
  
  for (let i = 0; i <= 3; i++) {
    
    for (let a = 0; a <= 360; a += 100) {
      
      let r = 50*i;
      noFill();
  bezier(x - cos(a) * r, y + cos(a) * r,
         x - cos(a) * r,
         y,
         x ,
         y,
         x , y);
    }
  }

  pop();
}